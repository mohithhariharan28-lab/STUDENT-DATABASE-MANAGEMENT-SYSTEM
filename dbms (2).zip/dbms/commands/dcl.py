# =============================================================================
# commands/dcl.py
# Handlers for DCL (Data Control Language) commands:
#   GRANT, REVOKE
# =============================================================================

from utils.formatter import (
    print_separator, print_success, print_error,
    print_info, print_warning
)


def _execute_dcl(cursor, connection, sql: str, label: str) -> bool:
    """
    Executes a DCL command.
    GRANT/REVOKE implicitly commit, so no manual commit is needed.
    Returns True on success, False on failure.
    """
    try:
        cursor.execute(sql)
        print_success(f"{label} statement executed successfully.")
        return True
    except Exception as e:
        print_error(f"{label} failed: {e}")
        return False


def handle_grant(cursor, connection):
    """Prompt the user to enter a GRANT statement and execute it."""
    print_separator("-")
    print_info("[ GRANT ]  Enter your GRANT statement.")
    print_warning("Example: GRANT SELECT ON db.* TO 'user'@'localhost';")
    sql = input("  SQL> ").strip()
    if not sql:
        print_warning("No statement entered. Returning to menu.")
        return
    _execute_dcl(cursor, connection, sql, "GRANT")


def handle_revoke(cursor, connection):
    """Prompt the user to enter a REVOKE statement and execute it."""
    print_separator("-")
    print_info("[ REVOKE ]  Enter your REVOKE statement.")
    print_warning("Example: REVOKE SELECT ON db.* FROM 'user'@'localhost';")
    sql = input("  SQL> ").strip()
    if not sql:
        print_warning("No statement entered. Returning to menu.")
        return
    _execute_dcl(cursor, connection, sql, "REVOKE")
