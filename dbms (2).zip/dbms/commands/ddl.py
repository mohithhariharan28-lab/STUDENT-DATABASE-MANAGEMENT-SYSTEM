# =============================================================================
# commands/ddl.py
# Handlers for DDL (Data Definition Language) commands:
#   CREATE, ALTER, DROP, TRUNCATE, RENAME
# =============================================================================

from utils.formatter import (
    print_separator, print_success, print_error,
    print_info, print_warning
)


# ---------------------------------------------------------------------------
# Internal helper
# ---------------------------------------------------------------------------

def _execute_ddl(cursor, connection, sql: str, label: str) -> bool:
    """
    Executes a DDL statement.
    DDL in MySQL implicitly commits, so no manual commit is needed.
    Returns True on success, False on failure.
    """
    try:
        cursor.execute(sql)
        print_success(f"{label} statement executed successfully.")
        return True
    except Exception as e:
        print_error(f"{label} failed: {e}")
        return False


# ---------------------------------------------------------------------------
# Public handler functions (called from main.py)
# ---------------------------------------------------------------------------

def handle_create(cursor, connection):
    """Prompt the user to enter a CREATE statement and execute it."""
    print_separator("-")
    print_info("[ CREATE ]  Enter your CREATE statement.")
    print_warning("Example: CREATE TABLE students (id INT PRIMARY KEY, name VARCHAR(50));")
    sql = input("  SQL> ").strip()
    if not sql:
        print_warning("No statement entered. Returning to menu.")
        return
    _execute_ddl(cursor, connection, sql, "CREATE")


def handle_alter(cursor, connection):
    """Prompt the user to enter an ALTER statement and execute it."""
    print_separator("-")
    print_info("[ ALTER ]  Enter your ALTER statement.")
    print_warning("Example: ALTER TABLE students ADD COLUMN age INT;")
    sql = input("  SQL> ").strip()
    if not sql:
        print_warning("No statement entered. Returning to menu.")
        return
    _execute_ddl(cursor, connection, sql, "ALTER")


def handle_drop(cursor, connection):
    """Prompt the user to enter a DROP statement and execute it."""
    print_separator("-")
    print_info("[ DROP ]  Enter your DROP statement.")
    print_warning("Example: DROP TABLE students;")
    confirm = input("  ⚠  This is irreversible. Are you sure? (yes/no): ").strip().lower()
    if confirm != "yes":
        print_warning("DROP cancelled.")
        return
    sql = input("  SQL> ").strip()
    if not sql:
        print_warning("No statement entered. Returning to menu.")
        return
    _execute_ddl(cursor, connection, sql, "DROP")


def handle_truncate(cursor, connection):
    """Prompt the user to enter a TRUNCATE statement and execute it."""
    print_separator("-")
    print_info("[ TRUNCATE ]  Enter your TRUNCATE statement.")
    print_warning("Example: TRUNCATE TABLE students;")
    confirm = input("  ⚠  This will delete ALL rows. Are you sure? (yes/no): ").strip().lower()
    if confirm != "yes":
        print_warning("TRUNCATE cancelled.")
        return
    sql = input("  SQL> ").strip()
    if not sql:
        print_warning("No statement entered. Returning to menu.")
        return
    _execute_ddl(cursor, connection, sql, "TRUNCATE")


def handle_rename(cursor, connection):
    """Prompt the user to enter a RENAME statement and execute it."""
    print_separator("-")
    print_info("[ RENAME ]  Enter your RENAME statement.")
    print_warning("Example: RENAME TABLE old_name TO new_name;")
    sql = input("  SQL> ").strip()
    if not sql:
        print_warning("No statement entered. Returning to menu.")
        return
    _execute_ddl(cursor, connection, sql, "RENAME")
