# =============================================================================
# utils/formatter.py
# Shared formatting utilities for clean terminal output.
# =============================================================================


# ANSI colour codes for terminals that support them
_GREEN  = "\033[92m"
_RED    = "\033[91m"
_YELLOW = "\033[93m"
_CYAN   = "\033[96m"
_RESET  = "\033[0m"
_BOLD   = "\033[1m"


def print_separator(char="-", width=55):
    """Prints a horizontal separator line."""
    print(char * width)


def print_success(message):
    """Prints a green success message."""
    print(f"{_GREEN}[+] {message}{_RESET}")


def print_error(message):
    """Prints a red error message."""
    print(f"{_RED}[!] ERROR: {message}{_RESET}")


def print_info(message):
    """Prints a cyan informational message."""
    print(f"{_CYAN}{message}{_RESET}")


def print_warning(message):
    """Prints a yellow warning message."""
    print(f"{_YELLOW}[~] {message}{_RESET}")


def print_results(cursor):
    """
    Fetches and pretty-prints SELECT query results.
    Reads column names from cursor.description and builds an aligned table.
    """
    rows = cursor.fetchall()

    if not rows:
        print_warning("Query returned 0 rows.")
        return

    # Get column headers from the cursor description
    columns = [desc[0] for desc in cursor.description]

    # Calculate column widths (max of header vs data length)
    col_widths = [len(col) for col in columns]
    for row in rows:
        for i, cell in enumerate(row):
            col_widths[i] = max(col_widths[i], len(str(cell)))

    # Build header row
    header = " | ".join(col.ljust(col_widths[i]) for i, col in enumerate(columns))
    divider = "-+-".join("-" * w for w in col_widths)

    print(f"\n{_BOLD}{header}{_RESET}")
    print(divider)

    # Print each data row
    for row in rows:
        line = " | ".join(str(cell).ljust(col_widths[i]) for i, cell in enumerate(row))
        print(line)

    print_separator("-", len(divider))
    print_success(f"{len(rows)} row(s) returned.")
