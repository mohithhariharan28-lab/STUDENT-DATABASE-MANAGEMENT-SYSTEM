# =============================================================================
# commands/tcl.py
# Handlers for TCL (Transaction Control Language) commands:
#   COMMIT, ROLLBACK, SAVEPOINT, RELEASE SAVEPOINT, ROLLBACK TO SAVEPOINT
# =============================================================================

from utils.formatter import (
    print_separator, print_success, print_error,
    print_info, print_warning
)


def handle_commit(cursor, connection):
    """Commit the current transaction."""
    print_separator("-")
    print_info("[ COMMIT ]  Committing current transaction...")
    try:
        connection.commit()
        print_success("Transaction committed successfully.")
    except Exception as e:
        print_error(f"COMMIT failed: {e}")


def handle_rollback(cursor, connection):
    """Rollback the current transaction."""
    print_separator("-")
    print_info("[ ROLLBACK ]  Rolling back current transaction...")
    try:
        connection.rollback()
        print_success("Transaction rolled back successfully.")
    except Exception as e:
        print_error(f"ROLLBACK failed: {e}")


def handle_savepoint(cursor, connection):
    """Create a named savepoint in the current transaction."""
    print_separator("-")
    print_info("[ SAVEPOINT ]  Enter savepoint name:")
    name = input("  Savepoint name: ").strip()
    if not name:
        print_warning("No name entered. Returning to menu.")
        return
    try:
        cursor.execute(f"SAVEPOINT {name}")
        print_success(f"Savepoint '{name}' created.")
    except Exception as e:
        print_error(f"SAVEPOINT failed: {e}")


def handle_release_savepoint(cursor, connection):
    """Release (remove) a named savepoint."""
    print_separator("-")
    print_info("[ RELEASE SAVEPOINT ]  Enter savepoint name to release:")
    name = input("  Savepoint name: ").strip()
    if not name:
        print_warning("No name entered. Returning to menu.")
        return
    try:
        cursor.execute(f"RELEASE SAVEPOINT {name}")
        print_success(f"Savepoint '{name}' released.")
    except Exception as e:
        print_error(f"RELEASE SAVEPOINT failed: {e}")


def handle_rollback_to(cursor, connection):
    """Rollback to a named savepoint."""
    print_separator("-")
    print_info("[ ROLLBACK TO SAVEPOINT ]  Enter savepoint name to rollback to:")
    name = input("  Savepoint name: ").strip()
    if not name:
        print_warning("No name entered. Returning to menu.")
        return
    try:
        cursor.execute(f"ROLLBACK TO SAVEPOINT {name}")
        print_success(f"Rolled back to savepoint '{name}'.")
    except Exception as e:
        print_error(f"ROLLBACK TO SAVEPOINT failed: {e}")
