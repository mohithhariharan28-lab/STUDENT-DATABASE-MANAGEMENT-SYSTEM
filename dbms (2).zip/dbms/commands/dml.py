# =============================================================================
# commands/dml.py
# Handlers for DML (Data Manipulation Language) commands:
#   SELECT, INSERT, UPDATE, DELETE
# =============================================================================

from utils.formatter import (
    print_separator, print_success, print_error,
    print_info, print_warning, print_results
)


# ---------------------------------------------------------------------------
# Internal helper
# ---------------------------------------------------------------------------

def _execute_dml(cursor, connection, sql: str, label: str) -> bool:
    """
    Executes a DML statement and commits automatically.
    For SELECT, results are printed via print_results().
    Returns True on success, False on failure.
    """
    try:
        cursor.execute(sql)

        if label == "SELECT":
            print_results(cursor)
        else:
            connection.commit()
            print_success(
                f"{label} executed successfully. "
                f"Rows affected: {cursor.rowcount}"
            )
        return True
    except Exception as e:
        print_error(f"{label} failed: {e}")
        try:
            connection.rollback()
            print_warning("Transaction rolled back due to error.")
        except Exception:
            pass
        return False


# ---------------------------------------------------------------------------
# Public handler functions
# ---------------------------------------------------------------------------

def handle_select(cursor, connection):
    """Prompt the user to enter a SELECT statement and display results."""
    print_separator("-")
    print_info("[ SELECT ]  Enter your SELECT statement.")
    print_warning("Example: SELECT * FROM students;")
    sql = input("  SQL> ").strip()
    if not sql:
        print_warning("No statement entered. Returning to menu.")
        return
    _execute_dml(cursor, connection, sql, "SELECT")


def handle_insert(cursor, connection):
    """Prompt the user to enter an INSERT statement and execute it."""
    print_separator("-")
    print_info("[ INSERT ]  Enter your INSERT statement.")
    print_warning("Example: INSERT INTO students (id, name) VALUES (1, 'Alice');")
    sql = input("  SQL> ").strip()
    if not sql:
        print_warning("No statement entered. Returning to menu.")
        return
    _execute_dml(cursor, connection, sql, "INSERT")


def handle_update(cursor, connection):
    """Prompt the user to enter an UPDATE statement and execute it."""
    print_separator("-")
    print_info("[ UPDATE ]  Enter your UPDATE statement.")
    print_warning("Example: UPDATE students SET name='Bob' WHERE id=1;")
    sql = input("  SQL> ").strip()
    if not sql:
        print_warning("No statement entered. Returning to menu.")
        return
    _execute_dml(cursor, connection, sql, "UPDATE")


def handle_delete(cursor, connection):
    """Prompt the user to enter a DELETE statement and execute it."""
    print_separator("-")
    print_info("[ DELETE ]  Enter your DELETE statement.")
    print_warning("Example: DELETE FROM students WHERE id=1;")
    sql = input("  SQL> ").strip()
    if not sql:
        print_warning("No statement entered. Returning to menu.")
        return
    _execute_dml(cursor, connection, sql, "DELETE")
