# =============================================================================
# commands/query.py
# Handler for free-form / manual SQL query execution.
# Detects whether the query is a SELECT and responds appropriately.
# =============================================================================

from utils.formatter import (
    print_separator, print_success, print_error,
    print_info, print_warning, print_results
)

# Keywords that return a result set
_SELECT_KEYWORDS = ("SELECT", "SHOW", "DESCRIBE", "DESC", "EXPLAIN")


def handle_manual_query(cursor, connection):
    """
    Prompt the user to type any SQL query/statement and execute it.
    - If it looks like a SELECT-type query, results are displayed.
    - Otherwise the statement is executed and committed automatically.
    - Multi-line input is supported: enter an empty line to submit.
    """
    print_separator("-")
    print_info("[ MANUAL QUERY ]  Enter your SQL query/statement.")
    print_info("  (Type on one line, or press Enter twice to submit multi-line input.)")
    print_warning("  Type 'cancel' on an empty line to abort.")

    lines = []
    while True:
        line = input("  ... " if lines else "  SQL> ")
        if line.strip().lower() == "cancel":
            print_warning("Query cancelled.")
            return
        lines.append(line)
        # Empty line signals end of multi-line input
        if line.strip() == "":
            break

    sql = " ".join(l for l in lines if l.strip()).strip()

    if not sql:
        print_warning("No query entered. Returning to menu.")
        return

    # Determine if query returns rows
    first_word = sql.split()[0].upper()
    is_select = first_word in _SELECT_KEYWORDS

    try:
        cursor.execute(sql)
        if is_select:
            print_results(cursor)
        else:
            connection.commit()
            print_success(
                f"Statement executed successfully. "
                f"Rows affected: {cursor.rowcount}"
            )
    except Exception as e:
        print_error(f"Query execution failed: {e}")
        try:
            connection.rollback()
            print_warning("Transaction rolled back due to error.")
        except Exception:
            pass
